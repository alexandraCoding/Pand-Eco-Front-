$(document).ready(function(){
    $(".update").click(function(){
        var id = $(this).data("uid");
        var f1 = $("#f1").html();
        var l1 = $("#l1").html();
        var e1 = $("#e1").html();
        var a1 = $("#a1").html();
        var p1 = $("#p1").html();
        var f2 = $("#f2").html();
        var l2 = $("#l2").html();
        var e2 = $("#e2").html();
        var a2 = $("#a2").html();
        var p2 = $("#p2").html();
        if(id==1){
            $("#fn").val(f1);
            $("#en").val(e1);
            $("#ln").val(l1);
            $("#an").val(a1);
            $("#pn").val(p1);

        }else if(id==2){
            $("#fn").val(f2);
            $("#en").val(e2);
            $("#ln").val(l2);
            $("#an").val(a2);
            $("#pn").val(p2);
        }
        $("#up").click(function(){
            if(id==1){
                var fn = $("#fn").val();
                var en = $("#en").val();
                var ln = $("#ln").val();  
                var an = $("#an").val();
                var pn = $("#pn").val();  
                $("#f1").html(fn);
                $("#e1").html(en);
                $("#l1").html(ln);
                $("#a1").html(an);
                $("#p1").html(pn);
            }else if(id==2){
                var fn = $("#fn").val();
                var en = $("#en").val();
                var ln = $("#ln").val();
                var an = $("#an").val();
                var pn = $("#pn").val();    
                $("#f2").html(fn);
                $("#e2").html(en);
                $("#l2").html(ln);
                $("#a2").html(an);
                $("#p2").html(pn);              
            }
        });
    });
    $(".delete").click(function(){
       var id = $(this).data("uid");
       $("#del").click(function(){
           if(id==1){
               $("#d1").html('');
           }else if(id==2){
               $("#d2").html('');
           }
       });
    });
 });